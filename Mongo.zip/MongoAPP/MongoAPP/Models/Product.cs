﻿using MongoDB.Bson;
using MongoDB.Bson.Serialization.Attributes;
using System;
using System.ComponentModel.DataAnnotations;

namespace MongoAPP.Models
{
    public class Product
    {
        [BsonRepresentation(BsonType.ObjectId)]
        public string Id { get; set; }
        [Display(Name = "Дата")]
        public string Date { get; set; }
        
        [Display(Name = "Проблемы")]
        public string Problem { get; set; }

    }
}