﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using MongoAPP.Models;

namespace MongoAPP.Models
{
    public class IndexViewModel
    {
        public FolterViewModel Filter { get; set; }
        public IEnumerable<Product> Products { get; set; }
    }
}
