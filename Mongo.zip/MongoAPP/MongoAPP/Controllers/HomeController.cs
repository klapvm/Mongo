﻿using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Http;
using MongoAPP.Models;

namespace MongoApp.Controllers
{
    public class HomeController : Controller
    {
        private readonly ProductService db;
        public HomeController(ProductService context)
        {
            db = context;
        }
        public async Task<IActionResult> Index(FolterViewModel filter)
        {
            var phones = await db.GetProducts(filter.Name);
            var model = new IndexViewModel { Products = phones, Filter = filter };
            return View(model);
        }

        public IActionResult Create()
        {
            return View();
        }
        [HttpPost]
        public async Task<IActionResult> Create(Product p)
        {
            if (ModelState.IsValid)
            {
                await db.Create(p);
                return RedirectToAction("Index");
            }
            return View(p);
        }
        public async Task<IActionResult> Delete(string id)
        {
            await db.Remove(id);
            return RedirectToAction("Index");
        }
    }
}